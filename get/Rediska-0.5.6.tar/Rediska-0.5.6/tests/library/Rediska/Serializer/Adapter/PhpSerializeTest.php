<?php

class Rediska_Serializer_Adapter_PhpSerializeTest extends Rediska_TestCase
{
    public function testSerialize()
    {
        $this->markTestIncomplete('Write me!');
    }
    
    public function testUnserialize()
    {
        $this->markTestIncomplete('Write me!');
    }
}