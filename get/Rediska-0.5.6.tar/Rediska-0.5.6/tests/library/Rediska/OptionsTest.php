<?php

class Rediska_OptionsTest extends Rediska_TestCase
{
    public function testConstruct()
    {
        $this->markTestIncomplete('Write me!');
    }
    
    public function testApplyDefaultOptions()
    {
        $this->markTestIncomplete('Write me!');
    }
    
    public function testSetOptions()
    {
        $this->markTestIncomplete('Write me!');
    }
    
    public function testGetOptions()
    {
        $this->markTestIncomplete('Write me!');
    }
    
    public function testSetOption()
    {
        $this->markTestIncomplete('Write me!');
    }
}
/*
class ClassWithOptionsForTest extends Rediska_Options
{
    protected $_options = array(
        'testOne' => 1,
        'testTwo' => 2,
    );
}
*/