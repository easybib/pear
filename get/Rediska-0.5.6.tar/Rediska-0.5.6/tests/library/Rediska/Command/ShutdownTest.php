<?php

class Rediska_Command_ShutdownTest extends Rediska_TestCase
{
    public function testShutdown()
    {
        $this->markTestIncomplete('Not tested!');
    }
}