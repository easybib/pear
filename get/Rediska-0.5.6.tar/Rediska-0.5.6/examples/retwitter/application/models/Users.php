<?php

class Users extends Rediska_Key_Set
{
    public function __construct()
    {
        parent::__construct('users');
    }
}