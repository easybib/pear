<?php

/**
 * Rediska PubSub unsubscribe response 
 * 
 * @author Ivan Shumkov
 * @package Rediska
 * @subpackage PublishSubscribe
 * @version @package_version@
 * @link http://rediska.geometria-lab.net
 * @license http://www.opensource.org/licenses/bsd-license.php
 */
class Rediska_PubSub_Response_Unsubscribe extends Rediska_PubSub_Response_Abstract
{
    
}