<?php

/**
 * Rediska Monitor exception
 * 
 * @author Ivan Shumkov
 * @package Rediska
 * @version @package_version@
 * @link http://rediska.geometria-lab.net
 * @license http://www.opensource.org/licenses/bsd-license.php
 */
class Rediska_Monitor_Exception extends Rediska_Exception
{
    
}