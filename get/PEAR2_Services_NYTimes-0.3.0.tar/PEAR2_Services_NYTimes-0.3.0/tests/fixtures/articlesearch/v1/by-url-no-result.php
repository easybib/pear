<?php
return array(
    'effectiveUrl' => 'http://api.nytimes.com/svc/search/v1/article?query=url%3Ahttp%3A%2F%2Fwww.nytimes.com%2F2011%2F07%2F09%2Fbusiness%2Feconomy%2Fjob-growth-falters-badly-clouding-hope-for-recovery.html&api-key=f8f203975851104767077c83bb51fd95%3A6%3A57657007',
    'body'         => '{"offset" : "0" , "results" : [] , "tokens" : ["url:http" , "www" , "nytimes" , "com" , "2012" , "09" , "05" , "opinion" , "why" , "mali" , "matters" , "html"] , "total" : 0}',
    'statusLine'   => 'HTTP/1.1 200 OK',
);
