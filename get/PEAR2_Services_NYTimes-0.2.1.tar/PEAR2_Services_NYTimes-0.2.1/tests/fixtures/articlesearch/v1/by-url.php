<?php
return array(
    'effectiveUrl' => 'http://api.nytimes.com/svc/search/v1/article?query=url%3Ahttp%3A%2F%2Fwww.nytimes.com%2F2011%2F07%2F09%2Fbusiness%2Feconomy%2Fjob-growth-falters-badly-clouding-hope-for-recovery.html&api-key=f8f203975851104767077c83bb51fd95%3A6%3A57657007',
    'body'         => '{"offset" : "0" , "results" : [{"body" : "For the second consecutive month, employers added scarcely any jobs in June, startling evidence that the economic recovery is stumbling. All levels of government shed workers, and hiring by companies continued to slow, resulting in a meager 18,000 new nonfarm payroll jobs last month, the Labor Department reported on Friday. The government also" , "byline" : "By MOTOKO RICH" , "date" : "20110709" , "title" : "Job Growth Falters, Clouding Hope for Recovery" , "url" : "http:\/\/www.nytimes.com\/2011\/07\/09\/business\/economy\/job-growth-falters-badly-clouding-hope-for-recovery.html"}] , "tokens" : ["url:http" , "www" , "nytimes" , "com" , "2011" , "07" , "09" , "business" , "economy" , "job" , "growth" , "falters" , "badly" , "clouding" , "hope" , "for" , "recovery" , "html"] , "total" : 1}',
    'statusLine'   => 'HTTP/1.1 200 OK',
);
