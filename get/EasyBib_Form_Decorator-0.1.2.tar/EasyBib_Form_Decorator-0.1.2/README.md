## Form Decorator

See `docs` folder for a example form and controller usage of decorator stuff

## MessagesFormatter

A View Helper to print out fancy twitter bootstrap messages.
Needs to be added to view helper (path)

## Usage

 1. Clone this repository
 2. pear install package.xml
 3. all files are in your `include_path`

