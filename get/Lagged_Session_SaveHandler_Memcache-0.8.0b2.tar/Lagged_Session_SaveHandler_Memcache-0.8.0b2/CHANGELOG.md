## 0.6.0

 * bugfix:
    * calling a static method
 * improvement:
    * refactored none-domain-specific methods to BaseAbstract
    * improved testsuite
    * refactored MySQL calls
    * improved README (with setup, testing, etc. instructions)
    * added 'testing' mode which throws exceptions (off by default)
 * feature:
    * added a Mysql-based session handler (stand-alone)

## 0.5.0

 * initial public release
