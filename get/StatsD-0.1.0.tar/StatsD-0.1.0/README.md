## php-statsd

A client library for statsd. Based on etsy's work (of course).
