# A wrapper for APIs of the NYTimes.

[![Build Status](https://secure.travis-ci.org/pear2/Services_NYTimes.png?branch=master)](http://travis-ci.org/pear2/Services_NYTimes)

## Currently supported:

 * Newswire: http://developer.nytimes.com/docs/read/times_newswire_api
 * Article Search (query:url only): http://developer.nytimes.com/docs/read/article_search_api
